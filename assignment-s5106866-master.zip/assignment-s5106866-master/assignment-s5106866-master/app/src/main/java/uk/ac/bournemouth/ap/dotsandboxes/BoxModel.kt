package uk.ac.bournemouth.ap.dotsandboxes

class BoxModel {
    //Sets all box dimensions to 'empty'
    var left = false
    var right = false
    var top = false
    var bottom = false
    var occupied = false

    constructor(
        l: Boolean,
        t: Boolean,
        r: Boolean,
        b: Boolean
               ) {
        left = l
        top = t
        right = r
        bottom = b
        occupied = l && t && r && b
    }
    //returns how many box sides are filled
    fun occupiedLineCount(): Int {
        var count = 0
        if (left) count++
        if (right) count++
        if (top) count++
        if (bottom) count++
        return count
    }
}