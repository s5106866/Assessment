package uk.ac.bournemouth.ap.dotsandboxes

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), PlayersStateView {
    protected var gameView: GameView? = null
    protected var player1name: TextView? = null
    protected  var player2name: TextView? = null
    protected  var player1state: TextView? = null
    protected  var player2state: TextView? = null
    protected  var player1occupying: TextView? = null

    protected var player2occupying: TextView? = null
    var currentPlayerPointer: ImageView? = null
    lateinit var players: Array<Player>

    var playersOccupying = arrayOf(0, 0)
    private var currentPlayer: Player? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        gameView = findViewById(R.id.gameView) as GameView
        gameView!!.setPlayersState(this)

        player1name = findViewById(R.id.player1name) as TextView
        player2name = findViewById(R.id.player2name) as TextView
        player1state = findViewById(R.id.player1state) as TextView
        player2state = findViewById(R.id.player2state) as TextView
        player1occupying = findViewById(R.id.player1occupying) as TextView
        player2occupying = findViewById(R.id.player2occupying) as TextView
        currentPlayerPointer = findViewById(R.id.playerNowPointer) as ImageView

        players = arrayOf(HumanPlayer("Player"), RandomAIPlayer("Computer"))
        startGame(players)
    }

    private fun startGame(players: Array<Player>) {
        gameView!!.startGame(players)
        updateState()
    }

    fun updateState() {
        runOnUiThread {
            if (currentPlayer === players[0]) {
                player1state!!.text = "Thinking"
                player2state!!.text = "Waiting"
                currentPlayerPointer!!.setImageResource(R.drawable.a1)
            } else if (currentPlayer === players[1]) {
                player2state!!.text = "Thinking"
                player1state!!.text = "Waiting"
                currentPlayerPointer!!.setImageResource(R.drawable.a2)
            }
            player1occupying!!.text = "Occupying " + playersOccupying[0]
            player2occupying!!.text = "Occupying " + playersOccupying[1]
        }
    }

    override fun setCurrentPlayer(player: Player?) {
        currentPlayer = player
        updateState()
    }


    override fun setPlayerOccupyingBoxesCount(player_occupyingBoxesCount_map: Map<Player?, Int?>?) {
        playersOccupying[0] = player_occupyingBoxesCount_map!![players[0]]!!
        playersOccupying[1] = player_occupyingBoxesCount_map[players[1]]!!
        updateState()
    }

    override fun setWinner(winner: Player?) {
        runOnUiThread {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Dots And Boxes")
                .setMessage(winner!!.getName().toString() + " Wins!")
                .setPositiveButton(
                    "Restart"
                                  ) { dialog, which -> recreate() }
                .setNeutralButton(
                    "Dismiss"
                                 ) { dialogInterface, i -> }.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.action_new) {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Dots And Boxes")
                    .setMessage("New game versus")
                    .setPositiveButton(
                        "Computer"
                                      ) { dialog, which ->
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Who goes first?")
                            .setPositiveButton(
                                "Computer"
                                              ) { dialogInterface, i ->
                                players = arrayOf(
                                    RandomAIPlayer("Computer"),
                                    HumanPlayer("Human")
                                                 )
                                startGame(players)
                                player1name!!.text = "Computer"
                                player2name!!.text = "Human"
                            }
                            .setNegativeButton(
                                "Human"
                                              ) { dialogInterface, i ->
                                players = arrayOf(
                                    HumanPlayer("Human"),
                                    RandomAIPlayer("Computer")
                                                 )
                                startGame(players)
                                player1name!!.text = "Human"
                                player2name!!.text = "Computer"
                            }.show()
                    }
                    .setNeutralButton(
                        "Human"
                                     ) { dialogInterface, i ->
                        players = arrayOf(
                            HumanPlayer("Player 1"),
                            HumanPlayer("Player 2")
                                         )
                        startGame(players)
                        player1name!!.text = "Player 1"
                        player2name!!.text = "Player 2"
                    }.show()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
