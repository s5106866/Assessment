package uk.ac.bournemouth.ap.dotsandboxes

abstract class Player(nameC: String) {
    private var name: String = nameC
    private lateinit var game: Graph

    companion object {
        fun indexIn(
            player: Player,
            players: Array<Player>
                   ): Int {
            for (i in players.indices) {
                if (player == players[i]) return i
            }
            return -1
        }
    }

    fun getGame(): Graph {
        return game
    }

    fun getName(): String {
        return name
    }

    abstract fun move(): Line?

    fun addToGame(gameGraph: Graph) {
        this.game = gameGraph
    }
}