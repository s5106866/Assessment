package uk.ac.bournemouth.ap.dotsandboxes

//sets directions for the lines
enum class Direction {
    HORIZONTAL, VERTICAL
}