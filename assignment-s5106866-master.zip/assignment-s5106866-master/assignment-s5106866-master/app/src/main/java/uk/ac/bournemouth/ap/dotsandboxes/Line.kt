package uk.ac.bournemouth.ap.dotsandboxes

class Line {
    private var direction: Direction? = null
    private var row = 0
    private var column = 0

    constructor(direction: Direction?, row: Int, column: Int) {
        this.direction = direction
        this.row = row
        this.column = column
    }

    fun direction(): Direction? {
        return direction
    }

    fun row(): Int {
        return row
    }

    fun column(): Int {
        return column
    }

    override fun equals(o: Any?): Boolean {
        if (this === o) return true
        if (o == null || javaClass != o.javaClass) return false
        val line: Line = o as Line
        return row == line.row && column == line.column && direction === line.direction
    }

    override fun toString(): String {
        return "direction:" + direction().toString()
            .toString() + "row:" + row.toString() + "column" + column
    }
}
