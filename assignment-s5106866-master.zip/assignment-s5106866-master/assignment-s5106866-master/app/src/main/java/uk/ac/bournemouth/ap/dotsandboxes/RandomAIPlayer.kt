package uk.ac.bournemouth.ap.dotsandboxes

import java.util.*

class RandomAIPlayer:Player {
    protected var safeLines: ArrayList<Line>? = null
    protected var goodLines: ArrayList<Line>? = null
    protected var badLines: ArrayList<Line>? = null

    constructor(name: String?) : super(name!!) {
        safeLines = ArrayList<Line>()
        goodLines = ArrayList<Line>()
        badLines = ArrayList<Line>()
    }
    //chooses next move, checks if line is empty
    protected fun nextMove(): Line? {
        if (goodLines!!.size != 0) return getBestGoodLine()
        return if (safeLines!!.size != 0) getRandomSafeLine() else getRandomBadLine()
    }

    override fun move(): Line? {
        initialiseLines()
        return nextMove()
    }

    private fun initialiseLines() {
        goodLines!!.clear()
        badLines!!.clear()
        safeLines!!.clear()
        for (i in 0..5) {
            for (j in 0..4) {
                if (!isHorizontalLineOccupied(i, j)) {
                    if (i == 0) {
                        when (getBox(i, j).occupiedLineCount()) {
                            3 -> goodLines!!.add(Line(Direction.HORIZONTAL, i, j))
                            2 -> badLines!!.add(Line(Direction.HORIZONTAL, i, j))
                            1, 0 -> safeLines!!.add(Line(Direction.HORIZONTAL, i, j))
                        }
                    } else if (i == 5) {
                        when (getBox(i - 1, j).occupiedLineCount()) {
                            3 -> goodLines!!.add(Line(Direction.HORIZONTAL, i, j))
                            2 -> badLines!!.add(Line(Direction.HORIZONTAL, i, j))
                            1, 0 -> safeLines!!.add(Line(Direction.HORIZONTAL, i, j))
                        }
                    } else {
                        if (getBox(i, j).occupiedLineCount() === 3
                            || getBox(i - 1, j).occupiedLineCount() === 3
                        ) goodLines!!.add(Line(Direction.HORIZONTAL, i, j))
                        if (getBox(i, j).occupiedLineCount() === 2
                            || getBox(i - 1, j).occupiedLineCount() === 2
                        ) badLines!!.add(Line(Direction.HORIZONTAL, i, j))
                        if (getBox(i, j).occupiedLineCount() < 2
                            && getBox(i - 1, j).occupiedLineCount() < 2
                        ) safeLines!!.add(Line(Direction.HORIZONTAL, i, j))
                    }
                }
                if (!isVerticalLineOccupied(j, i)) {
                    if (i == 0) {
                        if (getBox(
                                j,
                                i
                                  ).occupiedLineCount() === 3
                        ) goodLines!!.add(Line(Direction.VERTICAL, j, i))
                    } else if (i == 5) {
                        if (getBox(
                                j,
                                i - 1
                                  ).occupiedLineCount() === 3
                        ) goodLines!!.add(Line(Direction.VERTICAL, j, i))
                    } else {
                        if (getBox(j, i).occupiedLineCount() === 3
                            || getBox(j, i - 1).occupiedLineCount() === 3
                        ) goodLines!!.add(Line(Direction.VERTICAL, j, i))
                        if (getBox(j, i).occupiedLineCount() === 2
                            || getBox(j, i - 1).occupiedLineCount() === 2
                        ) badLines!!.add(Line(Direction.VERTICAL, j, i))
                        if (getBox(j, i).occupiedLineCount() < 2
                            && getBox(j, i - 1).occupiedLineCount() < 2
                        ) safeLines!!.add(Line(Direction.VERTICAL, j, i))
                    }
                }
            }
        }
    }

    protected fun getBox(row: Int, column: Int): BoxModel {
        return BoxModel(
            isVerticalLineOccupied(row, column), isHorizontalLineOccupied(row, column),
            isVerticalLineOccupied(row, column + 1), isHorizontalLineOccupied(row + 1, column)
                       )
    }

    protected fun isHorizontalLineOccupied(row: Int, column: Int): Boolean {
        return getGame()!!.isLineOccupied(Direction.HORIZONTAL, row, column)
    }

    protected fun isVerticalLineOccupied(row: Int, column: Int): Boolean {
        return getGame()!!.isLineOccupied(Direction.VERTICAL, row, column)
    }

    protected fun getBestGoodLine(): Line? {
        return goodLines!![0]
    }

    protected fun getRandomSafeLine(): Line? {
        return getRandomLine(safeLines)
    }

    protected fun getRandomBadLine(): Line? {
        return getRandomLine(badLines)
    }

    private fun getRandomLine(list: List<Line>?): Line? {
        return list!![(list.size * Math.random()).toInt()]
    }
}