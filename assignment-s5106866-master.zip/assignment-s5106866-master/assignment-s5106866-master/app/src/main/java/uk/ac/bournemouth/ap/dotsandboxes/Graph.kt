package uk.ac.bournemouth.ap.dotsandboxes

import java.util.*

class Graph : Observable {
    private var players: Array<uk.ac.bournemouth.ap.dotsandboxes.Player>
    private var currentPlayerIndex = 0
    private var width = 0
    private var height = 0
    private var occupied: Array<Array<uk.ac.bournemouth.ap.dotsandboxes.Player?>>
    private lateinit var horizontalLines: Array<IntArray>
    private lateinit var verticalLines: Array<IntArray>
    private var latestLine: Line? = null
    //Array for game board and lines
    constructor(width: Int, height: Int, players: Array<uk.ac.bournemouth.ap.dotsandboxes.Player>) {
        this.width = width
        this.height = height
        this.players = players
        occupied = Array(height) { arrayOfNulls<uk.ac.bournemouth.ap.dotsandboxes.Player>(width) }
        horizontalLines = Array(height + 1) { IntArray(width) }
        verticalLines = Array(height) { IntArray(width + 1) }
        addPlayersToGame(players)
        currentPlayerIndex = 0
    }

    fun getPlayers(): Array<uk.ac.bournemouth.ap.dotsandboxes.Player>? {
        return players
    }

    fun getWidth(): Int {
        return width
    }

    fun getHeight(): Int {
        return height
    }

    fun getLatestLine(): Line? {
        return latestLine
    }

    private fun addPlayersToGame(players: Array<uk.ac.bournemouth.ap.dotsandboxes.Player>) {
        for (player in players) {
            player.addToGame(this)
        }
    }

    fun start() {
        while (!isGameFinished()) {
            addMove(currentPlayer().move())
            setChanged()
            notifyObservers()
        }
    }

    fun addMove(move: Line?) {
        if (isLineOccupied(move)) {
            return
        }
        val newBoxOccupied = tryToOccupyBox(move)
        setLineOccupied(move)
        latestLine = move
        if (!newBoxOccupied) toNextPlayer()
    }

    fun currentPlayer(): uk.ac.bournemouth.ap.dotsandboxes.Player {
        return players[currentPlayerIndex]
    }
    //checks if line position is Full
    fun isLineOccupied(direction: Direction?, row: Int, column: Int): Boolean {
        return isLineOccupied(direction?.let { Line(it, row, column) })
    }

    fun isLineOccupied(line: Line?): Boolean {
        when (line!!.direction()) {
            Direction.HORIZONTAL -> return (horizontalLines[line.row()][line.column()] == 1
                    || horizontalLines[line.row()][line.column()] == 2)
            Direction.VERTICAL   -> return (verticalLines[line.row()][line.column()] == 1
                    || verticalLines[line.row()][line.column()] == 2)
        }
        throw IllegalArgumentException(line.direction().toString())
    }

    fun getLineOccupier(line: Line): Int {
        when (line.direction()) {
            Direction.HORIZONTAL -> return horizontalLines[line.row()][line.column()]
            Direction.VERTICAL   -> return verticalLines[line.row()][line.column()]
        }
        throw IllegalArgumentException(line.direction().toString())
    }

    fun getBoxOccupier(row: Int, column: Int): uk.ac.bournemouth.ap.dotsandboxes.Player? {
        return occupied[row][column]
    }

    fun getPlayerOccupyingBoxCount(player: uk.ac.bournemouth.ap.dotsandboxes.Player): Int {
        var count = 0
        for (i in 0 until getHeight()) {
            for (j in 0 until getWidth()) {
                if (getBoxOccupier(i, j) === player) count++
            }
        }
        return count
    }
    //Checks if Box is occupied
    private fun tryToOccupyBox(move: Line?): Boolean {
        val rightOccupied = tryToOccupyRightBox(move)
        val underOccupied = tryToOccupyUnderBox(move)
        val upperOccupied = tryToOccupyUpperBox(move)
        val leftOccupied = tryToOccupyLeftBox(move)
        return leftOccupied || rightOccupied || upperOccupied || underOccupied
    }
    //Sets the Line to occupied by current player
    private fun setLineOccupied(line: Line?) {
        when (line!!.direction()) {
            Direction.HORIZONTAL -> horizontalLines[line.row()][line.column()] =
                currentPlayerIndex + 1
            Direction.VERTICAL   -> verticalLines[line.row()][line.column()] =
                currentPlayerIndex + 1
        }
    }
    //Sets the box to occupied by current player
    private fun setBoxOccupied(
        row: Int,
        column: Int,
        player: uk.ac.bournemouth.ap.dotsandboxes.Player
                              ) {
        occupied[row][column] = player
    }

    private fun tryToOccupyUpperBox(move: Line?): Boolean {
        if (move!!.direction() !== Direction.HORIZONTAL || move!!.row() <= 0) return false
        return if (isLineOccupied(Direction.HORIZONTAL, move.row() - 1, move.column())
            && isLineOccupied(Direction.VERTICAL, move.row() - 1, move.column())
            && isLineOccupied(Direction.VERTICAL, move.row() - 1, move.column() + 1)
        ) {
            setBoxOccupied(move.row() - 1, move.column(), currentPlayer())
            true
        } else {
            false
        }
    }

    private fun tryToOccupyUnderBox(move: Line?): Boolean {
        if (move!!.direction() !== Direction.HORIZONTAL || move!!.row() >= height) return false
        return if (isLineOccupied(Direction.HORIZONTAL, move.row() + 1, move.column())
            && isLineOccupied(Direction.VERTICAL, move.row(), move.column())
            && isLineOccupied(Direction.VERTICAL, move.row(), move.column() + 1)
        ) {
            setBoxOccupied(move.row(), move.column(), currentPlayer())
            true
        } else {
            false
        }
    }

    private fun tryToOccupyLeftBox(move: Line?): Boolean {
        if (move!!.direction() !== Direction.VERTICAL || move!!.column() <= 0) return false
        return if (isLineOccupied(Direction.VERTICAL, move.row(), move.column() - 1)
            && isLineOccupied(Direction.HORIZONTAL, move.row(), move.column() - 1)
            && isLineOccupied(Direction.HORIZONTAL, move.row() + 1, move.column() - 1)
        ) {
            setBoxOccupied(move.row(), move.column() - 1, currentPlayer())
            true
        } else {
            false
        }
    }

    private fun tryToOccupyRightBox(move: Line?): Boolean {
        if (move!!.direction() !== Direction.VERTICAL || move!!.column() >= width) return false
        return if (isLineOccupied(Direction.VERTICAL, move.row(), move.column() + 1)
            && isLineOccupied(Direction.HORIZONTAL, move.row(), move.column())
            && isLineOccupied(Direction.HORIZONTAL, move.row() + 1, move.column())
        ) {
            setBoxOccupied(move.row(), move.column(), currentPlayer())
            true
        } else {
            false
        }
    }

    private fun toNextPlayer() {
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size
    }

    protected fun isGameFinished(): Boolean {
        for (i in 0 until getHeight()) {
            for (j in 0 until getWidth()) {
                if (getBoxOccupier(i, j) == null) return false
            }
        }
        return true
    }

    fun getWinner(): uk.ac.bournemouth.ap.dotsandboxes.Player? {
        if (!isGameFinished()) {
            return null
        }
        val playersOccupyingBoxCount = IntArray(players.size)
        for (i in players.indices) {
            playersOccupyingBoxCount[i] = getPlayerOccupyingBoxCount(players[i])
        }
        return if (playersOccupyingBoxCount[0] > playersOccupyingBoxCount[1]) players[0] else players[1]
    }
}