package uk.ac.bournemouth.ap.dotsandboxes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import java.util.*

//drawing initial game board
class GameView : View, Observer {
    val radius = 14.toFloat() / 824
    val start = 6.toFloat() / 824
    val add1 = 18.toFloat() / 824
    val add2 = 2.toFloat() / 824
    val add3 = 14.toFloat() / 824
    val add4 = 141.toFloat() / 824
    val add5 = 159.toFloat() / 824
    val add6 = 9.toFloat() / 824

    val playerColors: IntArray
    var game: Graph? = null
    var move: Line? = null
    var paint: Paint? = null
    private lateinit var playersState: PlayersStateView

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        paint = Paint()

        setOnTouchListener { v, event ->
            receiveInput(event)
            false
        }

        playerColors = intArrayOf(
            resources.getColor(R.color.colorPrimary),
            resources.getColor(R.color.colorAccent)
                                 )
    }
    //gets current player state from interface
    fun setPlayersState(playersState: PlayersStateView?) {
        this.playersState = playersState!!
    }
    //resets game board and begins the game
    fun startGame(players: Array<Player>) {
        game = Graph(5, 5, players)
        game!!.addObserver(this)
        object : Thread() {
            override fun run() {
                game!!.start()
            }
        }.start()
        postInvalidate()
    }
    //draws game board and dots
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0x00FFFFFF)
        val min = Math.min(width, height)
        val radius: Float = radius * min
        val start: Float = start * min
        val add1: Float = add1 * min
        val add2: Float = add2 * min
        val add4: Float = add4 * min
        val add5: Float = add5 * min
        val add6: Float = add6 * min

        //paint lines
        paint!!.color = -0x1000000
        for (i in 0 until game!!.getHeight() + 1) {
            for (j in 0 until game!!.getWidth()) {
                val horizontal = Line(Direction.HORIZONTAL, i, j)
                if (horizontal.equals(game!!.getLatestLine())) {
                    paint!!.color = -0x8900
                } else if (game!!.isLineOccupied(horizontal)) {
                    if (game!!.getLineOccupier(horizontal) === 1) paint!!.color =
                        playerColors[0] else paint!!.color =
                        playerColors[1]
                } else {
                    paint!!.color = -0x1
                }
                canvas.drawRect(
                    start + add5 * j + add1,
                    start + add5 * i + add2,
                    start + add5 * (j + 1),
                    start + add5 * i + add1
                            - add2,
                    paint!!
                               )
                val vertical = Line(Direction.VERTICAL, j, i)
                if (vertical.equals(game!!.getLatestLine())) {
                    paint!!.color = -0x8900
                } else if (game!!.isLineOccupied(vertical)) {
                    if (game!!.getLineOccupier(vertical) === 1) paint!!.color =
                        playerColors[0] else paint!!.color =
                        playerColors[1]
                } else {
                    paint!!.color = -0x1
                }
                canvas.drawRect(
                    start + add5 * i + add2,
                    start + add5 * j + add1,
                    start + add5 * i + add1 - add2,
                    start + add5
                            * (j + 1),
                    paint!!
                               )
            }
        }

        //paint boxes when all sides of box complete
        for (i in 0 until game!!.getWidth()) {
            for (j in 0 until game!!.getHeight()) {
                paint!!.color = if (game!!.getBoxOccupier(
                        j,
                        i
                                                         ) == null
                ) Color.TRANSPARENT else playerColors[Player.indexIn(
                    game!!.getBoxOccupier(
                        j,
                        i
                                         )!!, game!!.getPlayers()!!
                                                                    )]
                canvas.drawRect(
                    start + add5 * i + add1 + add2, start
                            + add5 * j + add1 + add2, (start + add5 * i + add1
                            + add4) - add2, start + add5 * j + add1 + add4
                            - add2, paint!!
                               )
            }
        }

        //paint points
        paint!!.color = resources.getColor(R.color.colorAccent)
        for (i in 0 until game!!.getHeight() + 1) {
            for (j in 0 until game!!.getWidth() + 1) {
                canvas.drawCircle(
                    start + add6 + j * add5 + 1, start + add6 + i * add5 + 1,
                    radius, paint!!
                                 )
            }
        }
        invalidate()
    }

   //reports screen and the direction of the line and on which box
    private fun receiveInput(event: MotionEvent) {
        if (event.action != MotionEvent.ACTION_DOWN) return
        val touchX = event.x
        val touchY = event.y
        val min = Math.min(width, height)
        val start: Float = start * min
        val add1: Float = add1 * min
        val add2: Float = add2 * min
        val add3: Float = add3 * min
        val add5: Float = add5 * min
        var d = -1
        var a = -1
        var b = -1
        for (i in 0..5) {
            for (j in 0..4) {
                if (start + add5 * j + add1 - add3 <= touchX && touchX <= start + add5 * (j + 1) + add3 && touchY >= start + add5 * i + add2 - add3 && touchY <= start + add5 * i + add1 - add2 + add3
                ) {
                    d = 0
                    a = i
                    b = j
                }
                if (start + add5 * i + add2 - add3 <= touchX && touchX <= start + add5 * i + add1 - add2 + add3 && touchY >= start + add5 * j + add1 - add3 && touchY <= start + add5 * (j + 1) + add3
                ) {
                    d = 1
                    a = j
                    b = i
                }
            }
        }
        if (a != -1 && b != -1) {
            val direction: Direction
            direction = if (d == 0) Direction.HORIZONTAL else Direction.VERTICAL
            move = Line(direction, a, b)
            try {
                (game!!.currentPlayer() as HumanPlayer).add(move)
            } catch (e: Exception) {
                Log.e("GameView", e.toString())
            }
        }
    }
    //checks for winner and updates game map
    override fun update(p0: Observable?, p1: Any?) {
        playersState.setCurrentPlayer(game!!.currentPlayer())
        val player_occupyingBoxCount_map: MutableMap<Player?, Int?> =
            HashMap()
        for (player in game!!.getPlayers()!!) {
            player_occupyingBoxCount_map[player] = game!!.getPlayerOccupyingBoxCount(player)
        }
        playersState.setPlayerOccupyingBoxesCount(player_occupyingBoxCount_map)

        val winner = game!!.getWinner()
        if (winner != null) {
            playersState.setWinner(winner)
        }
    }
}