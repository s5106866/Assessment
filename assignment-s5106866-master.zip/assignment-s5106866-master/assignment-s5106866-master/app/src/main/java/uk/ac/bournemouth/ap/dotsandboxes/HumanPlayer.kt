package uk.ac.bournemouth.ap.dotsandboxes

class HumanPlayer(nameC: String) : Player(nameC) {
    private val inputBuffer = arrayOfNulls<Line>(1)
    fun add(line: Line?) {
        synchronized(inputBuffer) {
            inputBuffer[0] = line
            (inputBuffer as Object).notify()
        }
    }

    private fun getInput(): Line {
        synchronized(inputBuffer) {
            if (inputBuffer[0] != null) {
                val temp = inputBuffer[0]
                inputBuffer[0] = null
                return temp!!
            }
            try {
                (inputBuffer as Object).wait()
            } catch (ignored: InterruptedException) {
            }
            return getInput()
        }
    }

    override fun move(): Line {
        return getInput()
    }
}
