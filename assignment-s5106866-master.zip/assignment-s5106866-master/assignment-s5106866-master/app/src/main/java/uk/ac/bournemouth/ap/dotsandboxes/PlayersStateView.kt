package uk.ac.bournemouth.ap.dotsandboxes

interface PlayersStateView {
    fun setCurrentPlayer(player: Player?)

    fun setPlayerOccupyingBoxesCount(player_occupyingBoxesCount_map: Map<Player?, Int?>?)

    fun setWinner(winner: Player?)
}